class DescuentoDiezPorciento implements EstrategiaDescuento {
    @Override
    public double aplicarDescuento(double precio) {
        return precio * 0.90;  // Aplica un 10% de descuento
    }
}