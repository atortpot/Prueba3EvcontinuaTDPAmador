package org.example;

public class SistemaMobiliarioImpl extends SistemaMobiliario {
}
