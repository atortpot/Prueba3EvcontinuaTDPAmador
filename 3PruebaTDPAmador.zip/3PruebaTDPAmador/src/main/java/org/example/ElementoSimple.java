package org.example;

public class ElementoSimple {
    public ElementoSimple(double v, int i) {
    }
}
