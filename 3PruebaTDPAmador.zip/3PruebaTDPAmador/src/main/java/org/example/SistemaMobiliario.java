package org.example;

public class SistemaMobiliario {
    public static void main(String[] args) {
        // Crear elementos simples con su precio y código
        ElementoSimple silla = new ElementoSimple(50.0, 101);
        ElementoSimple mesa = new ElementoSimple(150.0, 102);

        // Crear un kit de muebles con un código y una estrategia de descuento específica
        Kit kitMuebles = new Kit(201, new DescuentoDiezPorciento());

        // Agregar elementos simples al kit
        kitMuebles.agregarElemento(silla);
        kitMuebles.agregarElemento(mesa);

        // Mostrar el precio del kit después de aplicar el descuento
        System.out.println("Precio del kit (con descuento): " + kitMuebles.getPrecio());

        // Mostrar el código del kit
        System.out.println("Código del kit: " + kitMuebles.getCodigo());
    }
}