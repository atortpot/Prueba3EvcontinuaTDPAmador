package org.example;

public class DescuentoDiezPorciento {
}
