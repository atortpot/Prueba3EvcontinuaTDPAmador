package org.example;

public class Kit {
    public Kit(int i, DescuentoDiezPorciento descuentoDiezPorciento) {
    }

    public void agregarElemento(ElementoSimple silla) {
    }

    public String getPrecio() {
        return null;
    }

    public String getCodigo() {
        return null;
    }
}
