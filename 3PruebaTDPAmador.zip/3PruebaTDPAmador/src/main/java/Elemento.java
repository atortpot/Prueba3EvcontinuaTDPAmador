interface Elemento {
    double getPrecio();
    int getCodigo();
}
