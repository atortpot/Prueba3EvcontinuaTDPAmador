interface EstrategiaDescuento {
    double aplicarDescuento(double precio);
}