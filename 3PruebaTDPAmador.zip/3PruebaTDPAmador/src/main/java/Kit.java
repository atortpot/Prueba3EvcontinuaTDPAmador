import java.util.ArrayList;
import java.util.List;
class Kit implements Elemento {
    private List<Elemento> elementos;
    private int codigo;
    private EstrategiaDescuento estrategiaDescuento;

    public Kit(int codigo, EstrategiaDescuento estrategia) {
        this.codigo = codigo;
        this.elementos = new ArrayList<>();
        this.estrategiaDescuento = estrategia;
    }

    public void agregarElemento(Elemento elemento) {
        elementos.add(elemento);
    }

    @Override
    public double getPrecio() {
        double precioTotal = 0;
        for (Elemento elemento : elementos) {
            precioTotal += elemento.getPrecio();
        }
        return estrategiaDescuento.aplicarDescuento(precioTotal);
    }

    @Override
    public int getCodigo() {
        return codigo;
    }
}